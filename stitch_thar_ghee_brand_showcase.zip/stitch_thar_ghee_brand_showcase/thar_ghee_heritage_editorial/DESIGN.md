---
name: Thar Ghee Heritage Editorial
colors:
  surface: '#fdf9f1'
  surface-dim: '#dddad2'
  surface-bright: '#fdf9f1'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3eb'
  surface-container: '#f1ede6'
  surface-container-high: '#ece8e0'
  surface-container-highest: '#e6e2da'
  on-surface: '#1c1c17'
  on-surface-variant: '#4f453f'
  inverse-surface: '#31302b'
  inverse-on-surface: '#f4f0e8'
  outline: '#81746e'
  outline-variant: '#d3c3bc'
  surface-tint: '#73594b'
  primary: '#110401'
  on-primary: '#ffffff'
  primary-container: '#2e1b10'
  on-primary-container: '#9f8171'
  inverse-primary: '#e2c0ae'
  secondary: '#7b5827'
  on-secondary: '#ffffff'
  secondary-container: '#ffcf94'
  on-secondary-container: '#795726'
  tertiary: '#0d0600'
  on-tertiary: '#ffffff'
  tertiary-container: '#2d1c00'
  on-tertiary-container: '#b47c00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbc9'
  primary-fixed-dim: '#e2c0ae'
  on-primary-fixed: '#2a170c'
  on-primary-fixed-variant: '#594234'
  secondary-fixed: '#ffddb5'
  secondary-fixed-dim: '#edbe85'
  on-secondary-fixed: '#2a1800'
  on-secondary-fixed-variant: '#604012'
  tertiary-fixed: '#ffdeae'
  tertiary-fixed-dim: '#fdba45'
  on-tertiary-fixed: '#281900'
  on-tertiary-fixed-variant: '#604100'
  background: '#fdf9f1'
  on-background: '#1c1c17'
  surface-variant: '#e6e2da'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2.5rem
  margin: 1.25rem
  margin-desktop: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system expresses the regal quietude, sacred culinary heritage, and artisanal purity of the Thar desert. The visual language balances warm, sun-baked rustic authenticity with high-end luxury editorial restraint. Rather than leaning into kitsch or over-ornamented royal cliches, the aesthetic channels sovereign minimalism: expansive breathing space, deliberate archival typography, tactile earth pigments, and uncompromised structural balance.

### Core Brand Principles
- **Sacred Purity & Lineage:** Every touchpoint reflects the ancient Vedic Bilona method and timeless desert origin. Visuals prioritize authenticity, reverence, and unhurried craftsmanship.
- **Rustic Luxury Editorial:** High contrast between warm alabaster parchment surfaces, earthen brown typographic weight, and disciplined touches of molten ghee gold.
- **Tactile Serenity:** Interfaces feel hand-pressed, organic, and grounded. Interactions are deliberate, weighted, and serene rather than hyperactive or flashy.

### Target Audience & Mood
Curated for conscious luxury consumers, culinary connoisseurs, and modern households seeking verifiable authenticity, heritage provenance, and pure A2 nutrition. The UI evokes warmth, grounding, aristocratic trust, and sensorial richness.

## Colors

The palette is derived directly from the physical materials of the Thar desert: kiln-fired clay pots (*matkas*), hand-churned molten butter, sun-bleached sandstone architecture, and deep shade within royal havelis.

### Color Mapping & Roles
- **Primary (`#2E1B10` - Deep Desert Brown):** Serves as the bedrock tone for key structural elements, dominant headers, high-emphasis icons, and definitive borders. Evokes ancestral teak and weathered stone.
- **Secondary (`#C89D66` - Camel Tan / Sandstone):** Acts as the secondary layer for architectural dividers, subtle framing, badges, and secondary metadata accents.
- **Tertiary / Accent (`#D99B26` - Desert Saffron Gold):** Reserved strictly for moments of golden radiance—primary CTA states, verification seals, launch badges, and key storytelling highlights.
- **Neutral Canvas (`#F7F3EB` - Warm Desert Cream):** The base background surface representing unprocessed raw muslin cloth and sun-warmed lime wash. Provides comfort and richness without pure white digital glare.
- **Surface Elevation (`#F3EDE2` - Sun-baked Alabaster):** Applied to card backgrounds, interactive containers, and content bays.
- **Supporting Foliage (`#5E6350` - Desert Khejri Olive):** Used for botanical certification tags, purity indicators, and natural origin notes.
- **Text Tiers:**
  - Primary Content: `#1F1610` (Charcoal Umber) for maximum legibility and gravitas.
  - Secondary Content: `#68584D` (Earthen Ochre) for subtitles, captions, and narrative sidebars.

## Typography

The typographic hierarchy bridges high-end editorial literature and digital clarity. 

### Font Pairing Logic
- **Headlines & Editorial Titles (Playfair Display):** Imparts dignity, royal Rajasthan lineage, and heritage authority. Large display settings make use of italic accents for poetic words and product descriptors.
- **Body, UI & Dual Script Harmony (Plus Jakarta Sans):** Chosen for its exceptional open counters, warm geometric curves, and neutral harmony when placed beside Devanagari script for the brand motto (*शुद्धता, जो थार से आए*). It ensures clear legibility across ingredient lists, nutritional panels, and pre-order interfaces.

### Composition Guidelines
- Use uppercase styling with widened tracking (`0.08em` to `0.1em`) exclusively for category markers, pre-order badge indicators, and navigation links.
- Maintain generous line heights on body paragraphs (`1.5` to `1.6`) to reinforce the unhurried editorial narrative tone.

## Layout & Spacing

Layouts in this system favor asymmetry, rhythmic editorial cadence, and breathing room reminiscent of luxury broadsheet publications.

### Grid & Layout Structure
- **Desktop (1024px and above):** 12-column fluid grid constrained to a maximum content width of `1280px`. Outer margins expand to `4rem` (`space-desktop-margin`), ensuring a framed, gallery-like presentation.
- **Tablet (768px – 1023px):** 8-column grid with `1.5rem` gutters and `2rem` outer margins.
- **Mobile (Below 768px):** 4-column grid with `1rem` gutters and `1.25rem` margins. Editorial storytelling cards stack into a unified single-column vertical flow with generous vertical section padding (`space-xl`).

### Spacing Principles
- Avoid claustrophobic, data-dense layouts. Component padding defaults to `space-lg` to allow product imagery and heritage copy to coexist peacefully.
- Narrative sections (e.g., "The Bilona Process", "Desi Gir Cow Lineage") utilize alternating alignments anchored by fine horizontal rules and asymmetric margins.

## Elevation & Depth

This design system avoids sterile, cold drop shadows or excessive floating effects. Depth is expressed through **tonal layering**, **earthen hairline borders**, and **warm ambient halos**.

### Depth Layers
1. **Canvas Level (Flat / Ground):** The base neutral background (`#F7F3EB`). All layout origins start here.
2. **Surface Tier 1 (Content Plates & Vessel Cards):** Elevated using background tone `#F3EDE2` combined with a subtle 1px border colored with `#C89D66` at 35% opacity. No harsh drop shadow is present.
3. **Surface Tier 2 (Interactive Floating Trays, Modals & Drawer Overlays):** Uses an extra-soft ambient shadow tinted with warm umber rather than cold gray:
   - `box-shadow: 0 16px 36px -8px rgba(46, 27, 16, 0.08), 0 4px 12px -2px rgba(46, 27, 16, 0.04);`
4. **Gold Filigree Accents:** High-tier artifacts and pre-launch reservations use subtle double-line borders (`1px solid #C89D66` offset by `3px`) to simulate handcrafted royal packaging labels.

## Shapes

The shape system adopts a **Soft (`1`)** approach with micro-radii (4px base, 8px on larger panels). 

### Geometry Principles
- The visual tone references hand-cut paper tags, artisanal jars, stone architecture, and traditional packaging cartons.
- Circles are permitted exclusively for royal seal badges, stamp certifications, and circular cow-lineage emblems.
- High-level containers, product feature modules, and imagery blocks maintain crisp, structured geometry with soft, tactile 4px-8px corners to preserve heritage dignity rather than playful app-like softness.

## Components

### Buttons
- **Primary Action (Pre-order / Reserve Batch):** 
  - Background: `#2E1B10` (Primary Dark Brown) with crisp text in `#F7F3EB`.
  - Border: 1px solid `#D99B26` (Gold rim).
  - Hover: Background shifts to `#3D2516` with a golden box-shadow glow (`0 0 16px rgba(217, 155, 38, 0.2)`).
  - Padding: `14px 28px`, text in `label-lg` uppercase.
- **Secondary Action (Explore Heritage / Watch Process):**
  - Background: Transparent with `#F3EDE2` fill on hover.
  - Border: 1px solid `#C89D66`.
  - Text: `#2E1B10`.

### Cards (Product & Provenance)
- Background: `#F3EDE2`.
- Border: 1px solid `rgba(200, 157, 102, 0.3)`.
- Internal Spacing: `space-lg`.
- Imagery: Warm-toned photography framed with a subtle inner border inset (2px padding with an earthen hairline edge).

### Input Fields (Waitlist & VIP Notification)
- Background: `#FBF8F2`.
- Border: 1px solid `#C89D66`.
- Typography: `body-md` in `#1F1610`.
- Focus State: Border deepens to `#2E1B10` with an accent outline in `#D99B26` at 40% opacity. No harsh default blue halos.
- Label: Floating or top-aligned in `label-md` uppercase using `#68584D`.

### Badges & Purity Seals
- Background: Warm translucent amber (`rgba(217, 155, 38, 0.1)`).
- Border: 1px solid `#D99B26`.
- Text: `#2E1B10`, tracked uppercase, featuring small insignia (e.g., "A2 VEDIC BILONA", "BATCH 01").

### Lists & Heritage Steps
- Ordered milestones utilize roman numerals or Devanagari numerals formatted in `Playfair Display` Gold (`#D99B26`).
- Dividers between narrative list items use hairline rules (`1px solid rgba(200, 157, 102, 0.25)`).

### Selection Controls (Checkboxes & Radios)
- Box/Circle Border: 1.5px solid `#C89D66`.
- Selected State: Background fills with `#2E1B10` enclosing a saffron gold mark (`#D99B26`).